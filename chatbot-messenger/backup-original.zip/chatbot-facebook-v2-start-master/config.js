module.exports = {
    FB_PAGE_TOKEN: '',
    FB_VERIFY_TOKEN: '',
    FB_APP_SECRET: '',
    SERVER_URL: '',
    GOOGLE_PROJECT_ID: '',
    DF_LANGUAGE_CODE: '',
    GOOGLE_CLIENT_EMAIL: '',
    GOOGLE_PRIVATE_KEY: ''
};